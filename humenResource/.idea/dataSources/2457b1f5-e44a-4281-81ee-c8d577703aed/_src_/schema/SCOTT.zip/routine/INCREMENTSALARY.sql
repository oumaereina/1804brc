CREATE PROCEDURE incrementSalary(eid IN NUMBER)
  AS
  p_salary T_EMPLOYEE.e_salary%TYPE ;
  BEGIN
    SELECT E_SALARY INTO p_salary FROM T_EMPLOYEE WHERE E_ID=eid;
    UPDATE T_EMPLOYEE SET E_SALARY=E_SALARY+1000 WHERE eid=E_ID;
    dbms_output.put_line(p_salary);
  END;
/
